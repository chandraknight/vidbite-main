<footer>
    <div class="quickLinks d-flex">
        <p>
            <a href="{{route('home')}}">
                Store
            </a>
        </p>
        <p>
            |
        </p>

        <p>
            <a href="{{route('about')}}">
                About
            </a>
        </p>
        <p>
            |
        </p>
        <p>
            <a href="">
                Careers
            </a>
        </p>
        <p>
            |
        </p>
        <p>
            <a href="">
                News
            </a>
        </p>
        <p>
            |
        </p>
        <p>
            <a href="{{route('support')}}">
                Support
            </a>
        </p>

    </div>
    <div class="phone">
        <p>
            +09 090 0998738
        </p>
    </div>
    <div class="copyright">
        <p>
            Copyright © 2021 NOBLE GAMES. All Rights Reserved
        </p>
    </div>
</footer>
